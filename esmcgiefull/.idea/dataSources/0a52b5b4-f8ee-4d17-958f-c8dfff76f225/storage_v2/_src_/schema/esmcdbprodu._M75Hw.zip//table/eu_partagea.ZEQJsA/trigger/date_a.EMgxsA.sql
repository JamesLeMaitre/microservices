create definer = esmcdb@`%` trigger date_a
    before insert
    on eu_partagea
    for each row
    SET NEW.partagea_date = NOW();

