create definer = esmcdb@`%` trigger date_m
    before insert
    on eu_partagem
    for each row
    SET NEW.partagem_date = NOW();

