create definer = esmcdb@`%` trigger trigger_y
    before insert
    on eu_relevebancairedetail
    for each row
    SET NEW.relevebancairedetail_montant = REPLACE(NEW.relevebancairedetail_montant, '?', ''), NEW.relevebancairedetail_montant = REPLACE(NEW.relevebancairedetail_montant, 'ÿ', ''), NEW.relevebancairedetail_montant = REPLACE(NEW.relevebancairedetail_montant, ' ', ''), NEW.relevebancairedetail_montant = REPLACE(REPLACE(NEW.relevebancairedetail_montant, CHAR(13), ''), CHAR(10), '');

