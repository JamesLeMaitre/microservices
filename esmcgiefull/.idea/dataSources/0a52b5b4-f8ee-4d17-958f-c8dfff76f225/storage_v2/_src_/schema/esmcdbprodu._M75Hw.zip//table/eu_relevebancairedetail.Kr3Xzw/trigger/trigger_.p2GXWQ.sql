create definer = esmcdb@`%` trigger trigger_
    before update
    on eu_relevebancairedetail
    for each row
    SET NEW.relevebancairedetail_montant = REPLACE(NEW.relevebancairedetail_montant, '˜', ''), NEW.relevebancairedetail_montant = REPLACE(REPLACE(NEW.relevebancairedetail_montant, CHAR(13), ''), CHAR(10), '');

